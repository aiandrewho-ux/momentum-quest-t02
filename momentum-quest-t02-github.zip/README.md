# Momentum Quest — T02

A static web app preloaded with Andrew's current release task: **T02 — Core build — Finish flagship FAQ**.

## T02 steps

1. Open the money page in Elementor — 5 minutes.
2. Find and finish every cut-off FAQ answer — 20 minutes.
3. Resolve duplicate FAQ entries one pair at a time — 20 minutes.
4. Compare booking advice with the footer and make them match — 15 minutes.
5. Update the page, verify it, and send the live link — 10 minutes.

Prerequisite: Andrew's final wording and business policy.

Finished when every final question has a complete answer, duplicates are resolved, booking advice matches the footer, and the live link has been sent.

## GitHub Pages deployment

1. Create a GitHub repository, such as `momentum-quest-t02`.
2. Upload all files from this folder to the repository root.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Wait for GitHub to display the public URL.

No build command is needed. `index.html` is the entry page.

## Updates

Edit the files, commit, and push to `main`. GitHub Pages will republish the site. Use a separate branch for test changes before merging.

## Data

Progress is stored in browser IndexedDB when supported. Use **Settings → Export backup** before clearing browser data or changing devices.
